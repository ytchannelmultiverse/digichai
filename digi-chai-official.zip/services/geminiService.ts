
import { GoogleGenAI, Type } from "@google/genai";

// Function to get chai recommendation using Gemini API
export const getChaiRecommendation = async (mood: string, timeOfDay: string) => {
  // Always initialize GoogleGenAI inside the function with the latest API key.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `User is feeling "${mood}" at "${timeOfDay}". Recommend a specific type of Chai (tea) and a digital activity/vibe that matches the @digichaiofficial aesthetic.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          teaName: { type: Type.STRING },
          ingredients: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          ritualDescription: { type: Type.STRING },
          digitalVibe: { type: Type.STRING, description: "A creative or digital productivity recommendation" },
          aestheticQuote: { type: Type.STRING }
        },
        required: ["teaName", "ingredients", "ritualDescription", "digitalVibe", "aestheticQuote"]
      }
    }
  });

  // response.text is a getter property.
  const text = response.text;
  if (!text) {
    return {
      teaName: "Classic Masala Chai",
      ingredients: ["Black tea", "Milk", "Ginger", "Cardamom"],
      ritualDescription: "Take a deep breath and enjoy the warmth.",
      digitalVibe: "Focus mode enabled.",
      aestheticQuote: "Sip happens."
    };
  }
  return JSON.parse(text);
};
