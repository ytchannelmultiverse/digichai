
export interface Post {
  id: string;
  imageUrl: string;
  caption: string;
  likes: string;
  date: string;
}

export interface Article {
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  imageUrl: string;
}

export enum AppSection {
  Home = 'home',
  Gallery = 'gallery',
  Journal = 'journal',
  Sommelier = 'sommelier',
  Shop = 'shop'
}
