
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Gallery from './components/Gallery';
import Sommelier from './components/Sommelier';
import Collections from './components/Collections';
import { AppSection } from './types';
import { Mail, Instagram, Twitter, ChevronRight, Coffee, ArrowRight } from 'lucide-react';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<AppSection>(AppSection.Home);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeSection]);

  const JournalPreview = () => (
    <section className="py-32 bg-stone-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-16">
          <div>
            <span className="text-chai-gold font-bold tracking-[0.3em] uppercase text-[10px] mb-2 block">Insights</span>
            <h2 className="text-5xl font-bold text-stone-900">The Journal</h2>
          </div>
          <button className="hidden md:flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 hover:text-stone-900 transition-colors">
            View All Posts <ArrowRight size={14} />
          </button>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
          {[
            { 
              title: "The Masala Modernist: Why traditional chai fits your WFH setup.", 
              date: "Sept 12, 2024",
              image: "https://images.unsplash.com/photo-1594631252845-29fc458695d7?w=800"
            },
            { 
              title: "Minimalism is more than just white space—it's about intentional steeps.", 
              date: "Sept 05, 2024",
              image: "https://images.unsplash.com/photo-1544787210-2211d74fc596?w=800"
            },
            { 
              title: "How to edit your life like a premium Lightroom preset.", 
              date: "Aug 28, 2024",
              image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800"
            }
          ].map((article, i) => (
            <div key={i} className="group cursor-pointer">
              <div className="aspect-[4/3] overflow-hidden rounded-2xl mb-6 shadow-sm transition-all duration-500 group-hover:shadow-xl">
                <img src={article.image} alt={article.title} className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-700" />
              </div>
              <span className="text-stone-400 text-[10px] font-bold uppercase tracking-widest">{article.date}</span>
              <h3 className="text-xl font-bold mt-3 mb-4 text-stone-900 group-hover:text-chai-gold transition-colors leading-tight">{article.title}</h3>
              <p className="flex items-center gap-2 text-stone-900 font-bold text-[10px] uppercase tracking-widest group-hover:gap-4 transition-all">
                Read More <ArrowRight size={14} />
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen">
      <Navbar activeSection={activeSection} setActiveSection={setActiveSection} />
      
      {activeSection === AppSection.Home && (
        <main className="animate-[fadeIn_0.5s_ease-out]">
          <Hero />
          
          {/* Philosophy Section */}
          <section className="py-32 bg-white">
            <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-24 items-center">
              <div className="relative">
                <div className="aspect-[3/4] overflow-hidden rounded-3xl">
                  <img 
                    src="https://images.unsplash.com/photo-1558160074-4d7d8bdf4256?q=80&w=1000" 
                    className="w-full h-full object-cover"
                    alt="Chai ritual"
                  />
                </div>
                <div className="absolute -bottom-10 -right-10 w-2/3 bg-[#fdfbf7] p-12 rounded-2xl shadow-2xl border border-stone-100 hidden md:block">
                  <p className="serif italic text-2xl text-stone-800 leading-relaxed">
                    "We don't just brew tea; we curate moments of digital stillness."
                  </p>
                  <span className="text-[10px] font-bold tracking-[0.3em] uppercase text-chai-gold mt-6 block">— The Founder</span>
                </div>
              </div>
              <div className="space-y-10">
                <span className="text-chai-gold font-bold uppercase tracking-[0.3em] text-[10px]">The Philosophy</span>
                <h2 className="text-6xl font-bold text-stone-900 leading-[1.1]">Digital Soul, <br /> Traditional <br /> Heart.</h2>
                <div className="w-24 h-px bg-chai-gold" />
                <p className="text-stone-500 text-lg leading-relaxed font-light max-w-md">
                  Digi Chai is a space for the thinkers, the makers, and the restless dreamers. We believe that in an increasingly accelerated digital world, the slow art of brewing tea is not just a habit—it's a resistance.
                </p>
                <button className="px-10 py-4 border-2 border-stone-900 text-stone-900 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-stone-900 hover:text-white transition-all">
                  Our Method
                </button>
              </div>
            </div>
          </section>

          <Collections />
          <Sommelier />
          <Gallery />
          <JournalPreview />
          
          {/* Newsletter Section */}
          <section className="py-32 bg-stone-900 text-white overflow-hidden relative">
            <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
              <span className="text-chai-gold font-bold tracking-[0.4em] uppercase text-[10px] mb-6 block">Join the Circle</span>
              <h2 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">Beyond the <br /> <span className="serif italic font-normal">Algorithm.</span></h2>
              <p className="text-stone-400 mb-12 text-lg font-light max-w-lg mx-auto">
                Subscribe to our curated newsletter for seasonal blends, exclusive lifestyle content, and digital wellness tips.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input 
                  type="email" 
                  placeholder="Your Email Address" 
                  className="flex-1 bg-white/5 border border-white/10 px-8 py-4 rounded-full outline-none focus:border-chai-gold transition-colors text-sm" 
                />
                <button className="px-10 py-4 bg-white text-stone-900 rounded-full font-bold text-[10px] uppercase tracking-widest hover:bg-chai-gold hover:text-white transition-all shadow-xl shadow-white/5">
                  Subscribe
                </button>
              </div>
            </div>
            {/* Background elements */}
            <div className="absolute top-0 left-0 w-64 h-64 bg-chai-gold/5 rounded-full blur-[100px]" />
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-[100px]" />
          </section>
        </main>
      )}

      {activeSection === AppSection.Gallery && <div className="pt-20"><Gallery /></div>}
      {activeSection === AppSection.Sommelier && <div className="pt-20"><Sommelier /></div>}
      {activeSection === AppSection.Journal && <div className="pt-20"><JournalPreview /></div>}
      {activeSection === AppSection.Shop && <div className="pt-20"><Collections /></div>}

      {/* Footer */}
      <footer className="bg-white text-stone-900 py-32 border-t border-stone-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-16 mb-24">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-8">
                <div className="w-8 h-8 rounded-full bg-stone-900 flex items-center justify-center text-white">
                  <Coffee size={16} />
                </div>
                <span className="serif text-2xl font-bold tracking-tight text-stone-900">Digi Chai.</span>
              </div>
              <p className="text-stone-400 text-sm leading-relaxed font-light">
                Exploring the harmony between the digital future and our aromatic past. Based in the studio, thinking in spices.
              </p>
            </div>
            <div>
              <h5 className="text-stone-900 font-bold uppercase tracking-[0.2em] text-[10px] mb-8">Navigation</h5>
              <ul className="space-y-4 text-[10px] font-bold uppercase tracking-widest text-stone-400">
                <li><button onClick={() => setActiveSection(AppSection.Home)} className="hover:text-stone-900 transition-colors">Home</button></li>
                <li><button onClick={() => setActiveSection(AppSection.Shop)} className="hover:text-stone-900 transition-colors">Shop</button></li>
                <li><button onClick={() => setActiveSection(AppSection.Journal)} className="hover:text-stone-900 transition-colors">Journal</button></li>
                <li><button onClick={() => setActiveSection(AppSection.Sommelier)} className="hover:text-stone-900 transition-colors">Sommelier</button></li>
              </ul>
            </div>
            <div>
              <h5 className="text-stone-900 font-bold uppercase tracking-[0.2em] text-[10px] mb-8">Information</h5>
              <ul className="space-y-4 text-[10px] font-bold uppercase tracking-widest text-stone-400">
                <li><a href="#" className="hover:text-stone-900 transition-colors">Shipping & Returns</a></li>
                <li><a href="#" className="hover:text-stone-900 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-stone-900 transition-colors">Stockists</a></li>
                <li><a href="#" className="hover:text-stone-900 transition-colors">Contact Us</a></li>
              </ul>
            </div>
            <div>
              <h5 className="text-stone-900 font-bold uppercase tracking-[0.2em] text-[10px] mb-8">Social</h5>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full border border-stone-100 flex items-center justify-center text-stone-400 hover:bg-stone-900 hover:text-white transition-all"><Instagram size={18} /></a>
                <a href="#" className="w-10 h-10 rounded-full border border-stone-100 flex items-center justify-center text-stone-400 hover:bg-stone-900 hover:text-white transition-all"><Twitter size={18} /></a>
                <a href="#" className="w-10 h-10 rounded-full border border-stone-100 flex items-center justify-center text-stone-400 hover:bg-stone-900 hover:text-white transition-all"><Mail size={18} /></a>
              </div>
            </div>
          </div>
          <div className="pt-12 border-t border-stone-100 flex flex-col md:flex-row justify-between items-center gap-6 text-[9px] font-bold uppercase tracking-[0.3em] text-stone-400">
            <p>&copy; 2024 Digi Chai Official. All rights reserved.</p>
            <div className="flex gap-12">
              <span>Made in Code</span>
              <span>Sourced in Spirit</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
