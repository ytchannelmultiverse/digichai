
import React from 'react';
import { ShoppingBag } from 'lucide-react';

const BLENDS = [
  {
    name: "Signature Masala",
    price: "$24.00",
    description: "The foundation of our craft. Robust Assam CTC blended with seven hand-crushed spices.",
    image: "https://images.unsplash.com/photo-1544787210-2211d74fc596?q=80&w=600"
  },
  {
    name: "Ethereal Cardamom",
    price: "$28.00",
    description: "A lighter, floral profile. Premium green cardamom pods and white pepper.",
    image: "https://images.unsplash.com/photo-1517686469429-8bdb88b9f907?q=80&w=600"
  },
  {
    name: "Midnight Ginger",
    price: "$26.00",
    description: "Spicy, warming, and deep. Dried ginger root with a touch of smoked cloves.",
    image: "https://images.unsplash.com/photo-1594631252845-29fc458695d7?q=80&w=600"
  }
];

const Collections: React.FC = () => {
  return (
    <section className="bg-white py-32">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-end mb-20">
          <div className="max-w-xl">
            <span className="text-chai-gold font-bold tracking-[0.3em] uppercase text-[10px] mb-4 block">The Essentials</span>
            <h2 className="text-5xl font-bold text-stone-900 mb-6 leading-tight">Handcrafted <br /> Blends.</h2>
            <p className="text-stone-500 font-light text-lg">Small-batch teas designed for the modern palate, sourced responsibly from the foothills of Assam.</p>
          </div>
          <button className="mt-8 md:mt-0 px-8 py-3 bg-stone-900 text-white rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-chai-gold transition-colors flex items-center gap-2">
            <ShoppingBag size={14} /> Shop All Collections
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {BLENDS.map((blend, idx) => (
            <div key={idx} className="group cursor-pointer">
              <div className="aspect-[3/4] overflow-hidden rounded-2xl mb-8 bg-stone-50 relative">
                <img 
                  src={blend.image} 
                  alt={blend.name} 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-stone-900/0 group-hover:bg-stone-900/5 transition-colors" />
                <button className="absolute bottom-6 left-1/2 -translate-x-1/2 px-6 py-2 bg-white text-stone-900 text-[10px] font-bold uppercase tracking-widest rounded-full opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-300 shadow-xl">
                  Quick Add
                </button>
              </div>
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-bold text-stone-900">{blend.name}</h3>
                <span className="text-chai-gold font-bold text-sm">{blend.price}</span>
              </div>
              <p className="text-stone-500 text-sm font-light leading-relaxed">{blend.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Collections;
