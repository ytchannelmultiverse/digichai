
import React, { useState } from 'react';
import { Sparkles, Loader2, ThermometerSun, Moon, Coffee, Heart, Palette } from 'lucide-react';
import { getChaiRecommendation } from '../services/geminiService';

const Sommelier: React.FC = () => {
  const [mood, setMood] = useState('Productive');
  const [time, setTime] = useState('Morning');
  const [recommendation, setRecommendation] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleRecommend = async () => {
    setLoading(true);
    try {
      const data = await getChaiRecommendation(mood, time);
      setRecommendation(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="bg-stone-900 text-white py-24 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
        <svg viewBox="0 0 100 100" className="w-full h-full text-chai-gold fill-current">
          <circle cx="50" cy="50" r="40" />
        </svg>
      </div>

      <div className="max-w-5xl mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-chai-gold/20 text-chai-gold border border-chai-gold/30 text-xs font-bold uppercase tracking-widest mb-6">
            <Sparkles size={14} /> AI Powered
          </span>
          <h2 className="text-5xl font-bold mb-4">Digital Chai Sommelier</h2>
          <p className="text-stone-400 max-w-xl mx-auto italic font-light">Let our artificial intelligence curate the perfect steep for your current creative frequency.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <div className="bg-stone-800/50 p-10 rounded-3xl border border-stone-700/50 backdrop-blur-sm">
            <h3 className="text-xl font-bold mb-8 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-chai-gold text-white flex items-center justify-center text-sm">1</span>
              Set Your Vibration
            </h3>
            
            <div className="space-y-8">
              <div>
                <label className="block text-stone-500 uppercase tracking-widest text-xs font-bold mb-4">How are you feeling?</label>
                <div className="flex flex-wrap gap-3">
                  {['Productive', 'Nostalgic', 'Restless', 'Cozy', 'Minimalist', 'Chaotic'].map((m) => (
                    <button
                      key={m}
                      onClick={() => setMood(m)}
                      className={`px-6 py-3 rounded-xl transition-all font-medium text-sm
                        ${mood === m ? 'bg-chai-gold text-white shadow-lg shadow-chai-gold/30' : 'bg-stone-900 text-stone-400 hover:bg-stone-700 hover:text-white'}`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-stone-500 uppercase tracking-widest text-xs font-bold mb-4">Current Context</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: 'Morning', icon: ThermometerSun },
                    { label: 'Afternoon', icon: Coffee },
                    { label: 'Night', icon: Moon }
                  ].map((t) => (
                    <button
                      key={t.label}
                      onClick={() => setTime(t.label)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl transition-all
                        ${time === t.label ? 'bg-white text-stone-900 shadow-xl' : 'bg-stone-900 text-stone-400 hover:bg-stone-700'}`}
                    >
                      <t.icon size={20} />
                      <span className="text-xs font-bold uppercase tracking-tighter">{t.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <button 
                onClick={handleRecommend}
                disabled={loading}
                className="w-full py-4 bg-chai-gold text-white rounded-full font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-3 hover:bg-white hover:text-stone-900 transition-all disabled:opacity-50"
              >
                {loading ? <Loader2 size={20} className="animate-spin" /> : <Sparkles size={20} />}
                Brew Recommendation
              </button>
            </div>
          </div>

          <div className="min-h-[400px]">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center text-stone-500 space-y-4">
                <Loader2 size={48} className="animate-spin text-chai-gold" />
                <p className="font-light italic">Consulting the digital tea leaves...</p>
              </div>
            ) : recommendation ? (
              <div className="animate-[fadeIn_0.5s_ease-out] bg-white text-stone-900 p-10 rounded-3xl shadow-2xl relative">
                <div className="absolute top-6 right-6 text-chai-gold">
                  <Heart size={24} />
                </div>
                <span className="text-chai-gold font-bold uppercase tracking-widest text-[10px] block mb-2">The Recommendation</span>
                <h4 className="text-3xl font-bold mb-4">{recommendation.teaName}</h4>
                <div className="mb-6 flex flex-wrap gap-2">
                  {recommendation.ingredients.map((ing: string) => (
                    <span key={ing} className="px-3 py-1 bg-stone-100 text-stone-600 rounded-lg text-xs font-medium">{ing}</span>
                  ))}
                </div>
                
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-stone-100 flex items-center justify-center text-stone-400">
                      <Coffee size={18} />
                    </div>
                    <div>
                      <h5 className="font-bold text-xs uppercase tracking-widest text-stone-400 mb-1">The Ritual</h5>
                      <p className="text-sm leading-relaxed text-stone-600 italic">{recommendation.ritualDescription}</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-stone-100 flex items-center justify-center text-stone-400">
                      <Palette size={18} />
                    </div>
                    <div>
                      <h5 className="font-bold text-xs uppercase tracking-widest text-stone-400 mb-1">Digital Vibe</h5>
                      <p className="text-sm leading-relaxed text-stone-600 italic">{recommendation.digitalVibe}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-10 pt-10 border-t border-stone-100">
                  <p className="serif text-xl italic text-stone-800 leading-relaxed text-center">"{recommendation.aestheticQuote}"</p>
                </div>
              </div>
            ) : (
              <div className="h-full border-2 border-dashed border-stone-700 rounded-3xl flex flex-col items-center justify-center p-12 text-center text-stone-500">
                <Sparkles size={48} className="mb-6 opacity-20" />
                <p className="font-light italic max-w-xs">Your personalized curation will appear here. Select your parameters and start the brew.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Sommelier;
