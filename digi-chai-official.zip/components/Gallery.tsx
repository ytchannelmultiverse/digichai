
import React from 'react';
import { Heart, MessageCircle } from 'lucide-react';
import { Post } from '../types';

const MOCK_POSTS: Post[] = [
  { id: '1', imageUrl: 'https://images.unsplash.com/photo-1517686469429-8bdb88b9f907?w=600&h=600&fit=crop', caption: 'The early morning ritual.', likes: '1.2k', date: '2h ago' },
  { id: '2', imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&h=600&fit=crop', caption: 'Desks and decoctions.', likes: '940', date: '5h ago' },
  { id: '3', imageUrl: 'https://images.unsplash.com/photo-1561336313-0bd5e0b27ec8?w=600&h=600&fit=crop', caption: 'Monsoon mood with extra ginger.', likes: '2.1k', date: '1d ago' },
  { id: '4', imageUrl: 'https://images.unsplash.com/photo-1594631252845-29fc458695d7?w=600&h=600&fit=crop', caption: 'Golden hour in the studio.', likes: '1.5k', date: '2d ago' },
  { id: '5', imageUrl: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&h=600&fit=crop', caption: 'Notes and cardamom seeds.', likes: '880', date: '3d ago' },
  { id: '6', imageUrl: 'https://images.unsplash.com/photo-1558160074-4d7d8bdf4256?w=600&h=600&fit=crop', caption: 'The art of the steep.', likes: '1.1k', date: '4d ago' },
];

const Gallery: React.FC = () => {
  return (
    <section className="max-w-7xl mx-auto px-4 py-24">
      <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-6">
        <div className="max-w-2xl">
          <span className="text-chai-gold font-bold tracking-widest uppercase text-xs mb-4 block">Visual Diary</span>
          <h2 className="text-4xl md:text-5xl font-bold text-stone-800">Recent Steeps<span className="text-chai-gold">.</span></h2>
          <p className="mt-4 text-stone-500 font-light text-lg italic">Follow @digichaiofficial for a daily dose of chai aesthetic.</p>
        </div>
        <button className="px-8 py-3 border-2 border-stone-200 rounded-full text-stone-600 font-bold hover:bg-stone-50 transition-colors uppercase text-xs tracking-widest">
          View on Instagram
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {MOCK_POSTS.map((post) => (
          <div key={post.id} className="group relative aspect-square overflow-hidden rounded-2xl bg-stone-100 cursor-pointer shadow-sm hover:shadow-2xl transition-all duration-500">
            <img 
              src={post.imageUrl} 
              alt={post.caption}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:rotate-1"
            />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-8">
              <div className="flex justify-end gap-6 text-white font-medium">
                <span className="flex items-center gap-2"><Heart size={20} className="fill-white" /> {post.likes}</span>
                <span className="flex items-center gap-2"><MessageCircle size={20} /> 48</span>
              </div>
              <div>
                <p className="text-white text-lg font-medium leading-tight mb-2 line-clamp-2">{post.caption}</p>
                <span className="text-stone-300 text-xs uppercase tracking-widest">{post.date}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Gallery;
