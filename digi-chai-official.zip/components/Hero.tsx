
import React from 'react';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex flex-col justify-center overflow-hidden bg-[#fdfbf7]">
      <div className="max-w-7xl mx-auto px-4 w-full grid md:grid-cols-2 items-center gap-12 z-10">
        <div className="space-y-8 animate-[fadeIn_1s_ease-out]">
          <div className="inline-block">
            <span className="text-[10px] font-bold tracking-[0.4em] uppercase text-stone-400 border-b border-stone-200 pb-2 mb-6 block">
              Established in Tradition • Reimagined in Code
            </span>
          </div>
          <h1 className="text-7xl md:text-9xl font-bold leading-[0.9] text-stone-900">
            Slow <br />
            <span className="serif italic font-normal text-chai-gold">Steeps.</span><br />
            Fast Live.
          </h1>
          <p className="text-xl text-stone-500 max-w-md leading-relaxed font-light">
            A boutique digital platform celebrating the intersection of modern lifestyle and the timeless art of Masala Chai.
          </p>
          <div className="flex items-center gap-8 pt-4">
            <button className="group flex items-center gap-3 text-xs font-bold uppercase tracking-widest text-stone-900 hover:text-chai-gold transition-colors">
              Shop Blends <span className="w-12 h-[1px] bg-stone-900 group-hover:bg-chai-gold group-hover:w-16 transition-all"></span>
            </button>
            <button className="text-xs font-bold uppercase tracking-widest text-stone-400 hover:text-stone-900 transition-colors">
              Our Story
            </button>
          </div>
        </div>
        
        <div className="relative hidden md:block">
          <div className="aspect-[4/5] relative rounded-2xl overflow-hidden shadow-2xl scale-95 hover:scale-100 transition-transform duration-1000">
            <img 
              src="https://images.unsplash.com/photo-1594631252845-29fc458695d7?q=80&w=1000&auto=format&fit=crop" 
              alt="Premium Chai Culture"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-stone-900/10 mix-blend-multiply" />
          </div>
          <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-chai-gold/20 rounded-full blur-3xl" />
        </div>
      </div>

      <div className="absolute bottom-10 left-10 flex items-center gap-4 text-stone-300">
        <div className="w-px h-12 bg-stone-200" />
        <span className="text-[10px] uppercase tracking-[0.2em] font-bold vertical-text">Scroll</span>
      </div>
    </section>
  );
};

export default Hero;
