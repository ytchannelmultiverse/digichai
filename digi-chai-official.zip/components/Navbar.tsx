
import React, { useState, useEffect } from 'react';
import { Coffee, Instagram, BookOpen, LayoutGrid, ShoppingBag, Sparkles, Menu, X } from 'lucide-react';
import { AppSection } from '../types';

interface NavbarProps {
  activeSection: AppSection;
  setActiveSection: (section: AppSection) => void;
}

const Navbar: React.FC<NavbarProps> = ({ activeSection, setActiveSection }) => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: AppSection.Shop, label: 'Shop', icon: ShoppingBag },
    { id: AppSection.Journal, label: 'Journal', icon: BookOpen },
    { id: AppSection.Sommelier, label: 'Sommelier', icon: Sparkles },
    { id: AppSection.Gallery, label: 'Moments', icon: LayoutGrid },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${scrolled ? 'bg-white/95 backdrop-blur-md py-4 shadow-sm border-b border-stone-100' : 'bg-transparent py-8'}`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <button 
          className="md:hidden p-2 text-stone-900"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>

        <div className="hidden md:flex items-center gap-10">
          {navItems.slice(0, 2).map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`text-[10px] font-bold uppercase tracking-[0.3em] transition-colors
                ${activeSection === item.id ? 'text-chai-gold' : 'text-stone-500 hover:text-stone-900'}`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => setActiveSection(AppSection.Home)}
        >
          <span className="serif text-2xl font-bold tracking-tighter text-stone-900">
            Digi <span className="text-chai-gold italic font-normal">Chai.</span>
          </span>
        </div>

        <div className="hidden md:flex items-center gap-10">
          {navItems.slice(2).map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`text-[10px] font-bold uppercase tracking-[0.3em] transition-colors
                ${activeSection === item.id ? 'text-chai-gold' : 'text-stone-500 hover:text-stone-900'}`}
            >
              {item.label}
            </button>
          ))}
          <div className="w-px h-4 bg-stone-200" />
          <a href="#" className="text-stone-900 hover:text-chai-gold transition-colors">
            <ShoppingBag size={18} strokeWidth={1.5} />
          </a>
        </div>

        <div className="md:hidden">
          <a href="#" className="text-stone-900">
            <ShoppingBag size={18} strokeWidth={1.5} />
          </a>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden absolute top-full left-0 w-full bg-white border-t border-stone-100 transition-all duration-300 overflow-hidden ${menuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="p-8 flex flex-col gap-6">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveSection(item.id);
                setMenuOpen(false);
              }}
              className="text-left text-xs font-bold uppercase tracking-widest text-stone-500 hover:text-stone-900"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
